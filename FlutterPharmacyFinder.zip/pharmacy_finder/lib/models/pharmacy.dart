class Pharmacy {
  final String placeId;
  final String name;
  final String address;
  final double lat;
  final double lng;
  final bool isOpen;
  final double? rating;
  final int? userRatingsTotal;

  const Pharmacy({
    required this.placeId,
    required this.name,
    required this.address,
    required this.lat,
    required this.lng,
    this.isOpen = false,
    this.rating,
    this.userRatingsTotal,
  });

  factory Pharmacy.fromJson(Map<String, dynamic> json) {
    final geometry = json['geometry']['location'];
    final openingHours = json['opening_hours'];
    return Pharmacy(
      placeId: json['place_id'] as String? ?? '',
      name: json['name'] as String? ?? 'Unknown Pharmacy',
      address: json['vicinity'] as String? ??
          json['formatted_address'] as String? ??
          'No address',
      lat: (geometry['lat'] as num).toDouble(),
      lng: (geometry['lng'] as num).toDouble(),
      isOpen: openingHours != null
          ? (openingHours['open_now'] as bool? ?? false)
          : false,
      rating: json['rating'] != null
          ? (json['rating'] as num).toDouble()
          : null,
      userRatingsTotal: json['user_ratings_total'] as int?,
    );
  }
}
