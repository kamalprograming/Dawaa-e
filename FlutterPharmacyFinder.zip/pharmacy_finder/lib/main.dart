import 'package:flutter/material.dart';
import 'screens/map_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
// 🔑  REPLACE WITH YOUR GOOGLE MAPS / PLACES API KEY
// Get one at: https://console.cloud.google.com/
// Enable: Maps SDK for Android + Places API
// ─────────────────────────────────────────────────────────────────────────────
const String kGoogleApiKey = 'YOUR_GOOGLE_MAPS_API_KEY_HERE';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PharmacyFinderApp());
}

class PharmacyFinderApp extends StatelessWidget {
  const PharmacyFinderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pharmacy Finder',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1A73E8),
        useMaterial3: true,
      ),
      home: const MapScreen(googleApiKey: kGoogleApiKey),
    );
  }
}
