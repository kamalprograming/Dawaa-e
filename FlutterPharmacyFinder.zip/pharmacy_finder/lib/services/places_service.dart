import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/pharmacy.dart';

class PlacesService {
  final String apiKey;
  static const String _baseUrl =
      'https://maps.googleapis.com/maps/api/place';

  const PlacesService({required this.apiKey});

  Future<List<Pharmacy>> getNearbyPharmacies({
    required double lat,
    required double lng,
    int radiusMeters = 2000,
  }) async {
    final uri = Uri.parse(
      '$_baseUrl/nearbysearch/json'
      '?location=$lat,$lng'
      '&radius=$radiusMeters'
      '&type=pharmacy'
      '&key=$apiKey',
    );

    final response = await http.get(uri);

    if (response.statusCode != 200) {
      throw Exception(
          'Failed to fetch pharmacies (HTTP ${response.statusCode})');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final status = data['status'] as String;

    if (status == 'REQUEST_DENIED') {
      throw Exception('API key error: ${data['error_message']}');
    }
    if (status == 'ZERO_RESULTS') return [];
    if (status != 'OK') throw Exception('Places API error: $status');

    final results = data['results'] as List<dynamic>;
    return results
        .map((json) => Pharmacy.fromJson(json as Map<String, dynamic>))
        .toList();
  }
}
