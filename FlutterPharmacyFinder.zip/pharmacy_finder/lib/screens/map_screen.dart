import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../models/pharmacy.dart';
import '../services/location_service.dart';
import '../services/places_service.dart';
import '../widgets/pharmacy_bottom_sheet.dart';

class MapScreen extends StatefulWidget {
  final String googleApiKey;
  const MapScreen({super.key, required this.googleApiKey});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final Completer<GoogleMapController> _mapController = Completer();
  final LocationService _locationService = LocationService();
  late final PlacesService _placesService;

  Position? _currentPosition;
  List<Pharmacy> _pharmacies = [];
  final Map<MarkerId, Marker> _markers = {};

  bool _isLoading = true;
  String? _error;
  int _searchRadius = 2000;

  static const List<int> _radii = [500, 1000, 2000, 5000];

  @override
  void initState() {
    super.initState();
    _placesService = PlacesService(apiKey: widget.googleApiKey);
    _initMap();
  }

  Future<void> _initMap() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final position = await _locationService.getCurrentPosition();
      setState(() => _currentPosition = position);
      await _fetchPharmacies();
      await _moveCameraToUser();
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchPharmacies() async {
    if (_currentPosition == null) return;
    final pharmacies = await _placesService.getNearbyPharmacies(
      lat: _currentPosition!.latitude,
      lng: _currentPosition!.longitude,
      radiusMeters: _searchRadius,
    );
    if (mounted) {
      setState(() => _pharmacies = pharmacies);
      _buildMarkers();
    }
  }

  void _buildMarkers() {
    final Map<MarkerId, Marker> markers = {};

    // User marker
    if (_currentPosition != null) {
      const id = MarkerId('user_location');
      markers[id] = Marker(
        markerId: id,
        position:
            LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
        icon:
            BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        infoWindow: const InfoWindow(title: 'You are here'),
        zIndex: 2,
      );
    }

    // Pharmacy markers
    for (final p in _pharmacies) {
      final id = MarkerId(p.placeId);
      markers[id] = Marker(
        markerId: id,
        position: LatLng(p.lat, p.lng),
        icon: BitmapDescriptor.defaultMarkerWithHue(
          p.isOpen ? BitmapDescriptor.hueGreen : BitmapDescriptor.hueRed,
        ),
        onTap: () => _onPharmacyTapped(p),
      );
    }

    setState(() {
      _markers
        ..clear()
        ..addAll(markers);
    });
  }

  void _onPharmacyTapped(Pharmacy pharmacy) {
    if (_currentPosition == null) return;

    final distanceMeters = _locationService.distanceBetween(
      _currentPosition!.latitude,
      _currentPosition!.longitude,
      pharmacy.lat,
      pharmacy.lng,
    );

    // Animate camera to tapped pharmacy
    _mapController.future.then((ctrl) {
      ctrl.animateCamera(
        CameraUpdate.newLatLngZoom(LatLng(pharmacy.lat, pharmacy.lng), 16),
      );
    });

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => PharmacyBottomSheet(
        pharmacy: pharmacy,
        formattedDistance: _locationService.formatDistance(distanceMeters),
      ),
    );
  }

  Future<void> _moveCameraToUser() async {
    if (_currentPosition == null) return;
    final ctrl = await _mapController.future;
    await ctrl.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(
              _currentPosition!.latitude, _currentPosition!.longitude),
          zoom: 14.5,
        ),
      ),
    );
  }

  Future<void> _changeRadius(int radius) async {
    setState(() {
      _searchRadius = radius;
      _isLoading = true;
    });
    try {
      await _fetchPharmacies();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // ── Map ──────────────────────────────────────────────────────────
          if (_currentPosition != null)
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(_currentPosition!.latitude,
                    _currentPosition!.longitude),
                zoom: 14.5,
              ),
              onMapCreated: (ctrl) => _mapController.complete(ctrl),
              markers: Set<Marker>.of(_markers.values),
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              mapToolbarEnabled: false,
            )
          else if (_error == null)
            const Center(child: CircularProgressIndicator()),

          // ── Top UI ───────────────────────────────────────────────────────
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header card
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.12),
                          blurRadius: 12,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.local_pharmacy_rounded,
                            color: Color(0xFF1A73E8)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Pharmacy Finder',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: Color(0xFF1A1A2E),
                                ),
                              ),
                              Text(
                                _isLoading
                                    ? 'Searching...'
                                    : '${_pharmacies.length} pharmacies nearby',
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        if (_isLoading)
                          const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF1A73E8)),
                          ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 10),

                  // Radius filter chips
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _radii.map((r) {
                        final selected = _searchRadius == r;
                        final label =
                            r < 1000 ? '${r}m' : '${r ~/ 1000}km';
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () => _changeRadius(r),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                color: selected
                                    ? const Color(0xFF1A73E8)
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    blurRadius: 6,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                label,
                                style: TextStyle(
                                  color: selected
                                      ? Colors.white
                                      : const Color(0xFF1A1A2E),
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Error overlay ─────────────────────────────────────────────
          if (_error != null)
            Center(
              child: Container(
                margin: const EdgeInsets.all(24),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 20)
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline_rounded,
                        color: Colors.red, size: 48),
                    const SizedBox(height: 12),
                    const Text('Something went wrong',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    Text(_error!,
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 13),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _initMap,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1A73E8),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),

          // ── Legend ───────────────────────────────────────────────────
          if (_pharmacies.isNotEmpty)
            Positioned(
              bottom: 90,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 8)
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _legendDot(Colors.green, 'Open Now'),
                    const SizedBox(height: 4),
                    _legendDot(Colors.red, 'Closed'),
                    const SizedBox(height: 4),
                    _legendDot(Colors.blue, 'You'),
                  ],
                ),
              ),
            ),

          // ── My Location FAB ──────────────────────────────────────────
          Positioned(
            bottom: 32,
            right: 12,
            child: FloatingActionButton(
              mini: true,
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF1A73E8),
              onPressed: _moveCameraToUser,
              child: const Icon(Icons.my_location_rounded),
            ),
          ),
        ],
      ),
    );
  }

  Widget _legendDot(Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
            width: 10,
            height: 10,
            decoration:
                BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ],
    );
  }
}
